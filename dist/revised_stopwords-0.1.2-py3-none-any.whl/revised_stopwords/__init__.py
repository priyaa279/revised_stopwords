from .stopwords import get_revised_stopwords

__all__ = ["get_revised_stopwords"]